<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-8 mx-auto">
                 <form action="../code.php" method='post' enctype='multipart/form-data'>
                        <input type="text" placeholder='Enter product name' name='prod-name' class='form-control mt-3'>
                        <input type="number" placeholder='Enter product price' name='prod-price' class='form-control mt-3'>
                        <input type="text" placeholder='Enter product description' name='prod-description' class='form-control mt-3'>
                        <input type="number" placeholder='Enter product quantity' name='prod-quantity' class='form-control mt-3'>
                        <input type="file"  name='prod-image' class='form-control mt-3'>

                        
                        <select name="prod-category" class='form-control mt-3'>
                            <?php
                            include '../connection.php';
                         $fetch_cat =    mysqli_query($con, "SELECT * FROM add_category");  
                         foreach($fetch_cat as $cat){
                            ?>
                            <option value="<?php echo $cat['cat_id'];?>"><?php echo $cat['cat_name'];?></option>
                            <?php
                         }
                            ?>
                        </select>
                        <button type='submit' class='btn btn-dark mt-3' name='add-prod'>Add product</button>
                    </form>

                      <h3 class='mt-5 text-center'>Fetch products</h3>

                        <table class='table table-bordered table-hover table-striped'>
                            <tr>
                                <th>product id</th>
                                <th>product Name</th>
                                <th>product Description</th>
                                <th>product Price</th>
                                <th>product Quantity</th>
                                <th>product Image</th>
                            </tr>

                            <?php
                            include '../connection.php';
                         $fetch_cat =    mysqli_query($con, "SELECT * FROM add_product");
                         
                        foreach($fetch_cat as $categories){
                            ?>
                                <tr>
                                <td><?php echo $categories['pro_id'];?></td>
                                <td><?php echo $categories['pro_name'];?></td>
                                <td><?php echo $categories['pro_description'];?></td>
                                <td><?php echo $categories['pro_price'];?></td>
                                <td><?php echo $categories['pro_quantity'];?></td>
                                <td><img src="../images/<?php echo $categories['pro_image'];?>" alt="Product Image" width="300"></td>
                                </tr>

                                <?php
                        }

                            ?>
                        </table>


                </div>
            </div>
        </div>

            </div>
        </div>
    </div>
</body>
</html>