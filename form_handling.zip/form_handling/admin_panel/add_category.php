<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <h1 class='text-center mt-3'>Add categories</h1>


        <div class="container">
            <div class="row">
                <div class="col-8 mx-auto">
                    <form action="../code.php" method='post' enctype='multipart/form-data'>
                        <input type="text" placeholder='Enter category name' name='cat-name' class='form-control mt-3'>
                        <input type="file"  name='cat-image' class='form-control mt-3'>

                        <button type='submit' class='btn btn-dark mt-3' name='add-cat'>Add category</button>
                    </form>

                        <h3 class='mt-5 text-center'>Fetch Categories</h3>

                        <table class='table table-bordered table-hover table-striped'>
                            <tr>
                                <th>category id</th>
                                <th>category Name</th>
                                <th>category Image</th>
                            </tr>

                            <?php
                            include '../connection.php';
                         $fetch_cat =    mysqli_query($con, "SELECT * FROM add_category");
                         
                        foreach($fetch_cat as $categories){
                            ?>
                                <tr>
                                <td><?php echo $categories['cat_id'];?></td>
                                <td><?php echo $categories['cat_name'];?></td>
                                <td><?php echo $categories['cat_image'];?></td>
                                </tr>

                                <?php
                        }

                            ?>
                        </table>


                </div>
            </div>
        </div>






    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>