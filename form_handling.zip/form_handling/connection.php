<?php
$con =  mysqli_connect('localhost', 'root', '', 'formhandling');

// if($con){
//     echo 'db connected';
// };

?>