<?php

include 'connection.php';
session_start();

// register 

if(isset($_POST['register'])){
 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $city = $_POST['city'];
    $age = $_POST['age'] ;
    $gender = $_POST['gender'];


    $fetch_data = mysqli_query($con, "SELECT email FROM register WHERE email = '$email' ");

   if(mysqli_num_rows($fetch_data) > 0){
         echo "<script>
        alert('email id already exist')
        location.assign('register.php')
        </script>";
   }
   else{

    $insert = mysqli_query($con, "INSERT INTO register(name, email, password, city, age, gender)VALUES('$name', '$email', '$pass', '$city', '$age', '$gender')");

    if($insert){
        echo "<script>
        alert('data inserted successfully')
        location.assign('login.php')
        </script>";
    }
   }

}

//  Role based login 

if(isset($_POST['login'])){

    $email = $_POST['email'];
    $pass = $_POST['pass'];

    $data = mysqli_query($con, "SELECT * FROM register WHERE email = '$email' AND  password  = '$pass'");
    if(mysqli_num_rows($data) == 1){

       $value =  mysqli_fetch_assoc($data);

       if($value['role'] == 'admin'){
            // header('admin.php');

            $_SESSION['admin'] = $value['email'];
            $_SESSION['admin_name'] = $value['name'];
            $_SESSION['admin_id'] = $value['id'];


            echo "<script>
            alert('welcome to admin panel')
            location.assign('admin_panel/public.php?index')
            </script>";
            
       }
       elseif($value['role'] == 'user'){

          echo "<script>
            alert('welcome to user page')
            location.assign('user.php')
            </script>";
       }

    }else{

         echo "<script>
        alert('email id or is password incorrect')
        location.assign('login.php')
        </script>";


    }



}



// update data 
if(isset($_POST['update'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $city = $_POST['city'];
    $age = $_POST['age'];

   $update =  mysqli_query($con, "UPDATE register SET name = '$name', email = '$email', password = '$pass', city = '$city', age = '$age' where id = '$id' ");

   if($update){
        echo "<script>
        alert('data updated successfully')
        location.assign('admin_panel/public.php?index')
        </script>";
    }

}

// Delete data
if(isset($_POST['delete'])){
    $id = $_POST['id'];

    $delete = mysqli_query($con, "DELETE FROM register WHERE id = '$id'");

     if($delete){
        echo "<script>
        alert('data deleted successfully')
        location.assign('admin_panel/public.php?index')
        </script>";
    }
}

// add category 

if(isset($_POST['add-cat'])){

        $cat_name = $_POST['cat-name'];
        $cat_image = $_FILES['cat-image']['name'];
      
        $tmp_name = $_FILES['cat-image']['tmp_name'];
      
        $cat_size = $_FILES['cat-image']['size'];
        $image_type =pathinfo('$cat_image',PATHINFO_EXTENSION);



    move_uploaded_file($tmp_name,'./images/'.$cat_image);
    
    $insert_image = mysqli_query($con, "INSERT INTO add_category (cat_name , cat_image) VALUES ('$cat_name','$cat_image')");
 if($insert_image){
        echo "<script>
        alert('data inserted successfully')
        location.assign('admin_panel/public.php?category')
        </script>";
    }

      

        



}

?>
