<?php
$con =  mysqli_connect('localhost', 'root', '', 'department');

// if($con){
//     echo 'db connected';
// };

?>