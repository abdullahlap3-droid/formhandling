<?php
include 'connection.php';

if(isset($_POST['register'])){
 
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $city = $_POST['city'];
    $age = $_POST['age'] ;
    $gender = $_POST['gender'];


    $fetch_data = mysqli_query($con,"SELECT email FROM register WHERE email = '$email'");

    if(mysqli_num_rows($fetch_data)>0){
         echo "<script>
        alert('Email already exist')
        location.assign('register.php')
        </script>";
    }

    else{



        $insert = mysqli_query($con, "INSERT INTO register(name, email, password, city, age, gender)VALUES('$name', '$email', '$pass', '$city', '$age', '$gender')");
    
        if($insert){
            echo "<script>
            alert('data inserted successfully')
            location.assign('register.php')
            </script>";
        }
    }




}


    
if(isset($_POST['delete'])){
 
    $id = $_POST['id'];
    
    $delete = mysqli_query($con, "DELETE FROM register WHERE id ='$id'");

    if($delete){
        echo "<script>
        alert('data deleted successfully')
        location.assign('fetch.php')
        </script>";
    }

    // echo $name .'<br>';
    // echo $email .'<br>';
    // echo $pass .'<br>';
    // echo $city .'<br>';
    // echo $age .'<br>';
    // echo $gender .'<br>';
}


if(isset($_POST['edit'])){
 
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $city = $_POST['city'];
    $age = $_POST['age'] ;
    // $gender = $_POST['gender'];

    $edit = mysqli_query($con, "UPDATE register SET name ='$name', email ='$email', password = '$pass' , city = '$city' , age = '$age' where id = '$id'");

    if($edit){
        echo "<script>
        alert('data updated successfully')
        location.assign('fetch.php')
        </script>";
    }




}

?>