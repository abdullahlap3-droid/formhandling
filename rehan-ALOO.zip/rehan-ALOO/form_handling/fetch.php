<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
        <h1  class='text-center mt-3'>Fetch data</h1>

            <div class="container">
                <div class="row">
                    <div class="col-8 mx-auto">
                        <table class='table table-borderd table-hover table-striped'>
                            <tr>
                                <th>id</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>City</th>
                                <th>Age</th>
                                <th>Gender</th>
                                <th>role</th>
                                <th colspan=2>Action</th>
                            </tr>

                            <?php
                            include 'connection.php';
                     $select =   mysqli_query($con, "SELECT * FROM register where role = 'user' ");
                    
                     foreach($select as $value){
                        ?>
                        <tr>
                            <td><?php echo $value['id'] ;?></td>
                            <td><?php echo $value['name'] ;?></td>
                            <td><?php echo $value['email'] ;?></td>
                            <td><?php echo $value['password'] ;?></td>
                            <td><?php echo $value['city'] ;?></td>
                            <td><?php echo $value['age'] ;?></td>
                            <td><?php echo $value['gender'] ;?></td>
                            <td><?php echo $value['role'] ;?></td>
                            <td><button type="button" class="btn btn-warning" data-bs-toggle="modal"  data-bs-target="#delete<?php echo $value['id'] ;?>">
  delete
</button></td>

<!-- Modal -->
<div class="modal fade" id="delete<?php echo $value['id'] ;?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
<form action="code.php" method='post'>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Do you really want to delete?
                    <input type="hidden" placeholder="Enter your name" class="form-control mt-3" required name="id" VALUE=" <?php echo $value['id'] ;?>">

                    

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning" name='delete' >Delete</button>
      </div>

</form>
    </div>
  </div>
</div>




                            <td><button type="button" class="btn btn-primary" data-bs-toggle="modal"  data-bs-target="#edit<?php echo $value['id'] ;?>">
  edit
</button></td>
<!-- Modal -->
<div class="modal fade" id="edit<?php echo $value['id'] ;?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
<form action="code.php" method='post'>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       
                    <input type="text" placeholder="Enter your name" class="form-control mt-3" required name="id" VALUE=" <?php echo $value['id'] ;?>">
                    <input type="text" placeholder="Enter your name" class="form-control mt-3" required name="name" VALUE=" <?php echo $value['name'] ;?>">
                      <input type="email" placeholder="Enter your email" class="form-control mt-3" required name="email" VALUE='<?php echo $value['email'] ;?>'>

                    <input type="text" placeholder="Enter your password" class="form-control mt-3" required name="pass"  VALUE='<?php echo $value['password'] ;?>'> 

                    <input type="city" placeholder="Enter your city" class="form-control mt-3" required name="city"  VALUE='<?php echo $value['city'] ;?>'>

                    <input type="number" placeholder="Enter your age" class="form-control mt-3 mb-3" required name="age"  VALUE='<?php echo $value['age'] ;?>'>
                    

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-warning" name='edit' >Edit</button>
      </div>

</form>
    </div>
  </div>
</div>


        

                        </tr>

            <?php
                     }
                            ?>

                        </table>
                    </div>
                </div>
            </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js" integrity="sha384-G/EV+4j2dNv+tEPo3++6LCgdCROaejBqfUeNjuKAiuXbjrxilcCdDz6ZAVfHWe1Y" crossorigin="anonymous"></script>
  </body>
</html>